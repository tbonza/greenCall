

from twisted.internet import defer, reactor
import treq

def listCallback(results):
    for isSuccess, stuff in results:
        print "Successful? %s" % isSuccess
        #print "Content Length: %s" % len(content)
        print treq.content(stuff)

def finish(ign):
    reactor.stop()

def test():
    d1 = treq.request('GET', 'https://twitter.com/')
    d2 = treq.request('GET', 'https://www.pinterest.com/')
    dl = defer.DeferredList([d1, d2])
    dl.addCallback(listCallback)
    dl.addCallback(finish)

test()
reactor.run()



