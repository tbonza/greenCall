greencall
=========

Makes asyncronous API requests for various clients. Input a csv file and the
API results are written to MongoDb.

Only supports Python 3.4 because unicode. It's meant to be used with Flask.